const values = {
  UUID: "uuid",
  Int: 23,
  String: "A String.",
  Boolean: false,
};

type UUIDType = any;
type IntType = any;
type StringType = any;
type BooleanType = any;

export {};
