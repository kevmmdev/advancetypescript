const languages = ["java", "c", "go"];

type JavaOrGo = any; // "java" | "go"
type Languages = any; // "java" | "c" | "go"

export {};
