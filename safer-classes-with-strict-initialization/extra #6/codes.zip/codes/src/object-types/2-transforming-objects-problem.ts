export interface Obj {
  username: string;
  email: string;
  role: number;
}

type ObjSetters = unknown;

/*
{
  setUsername: () => void;
  setEmail: () => void;
  setRole: () => void;
}
*/
