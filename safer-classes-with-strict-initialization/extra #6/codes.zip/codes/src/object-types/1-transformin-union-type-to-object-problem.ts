export type Color = "red" | "green" | "blue";

type Colors = unknown;

/*
{
    red: "red";
    green: "green";
    blue: "blue";
}
*/
