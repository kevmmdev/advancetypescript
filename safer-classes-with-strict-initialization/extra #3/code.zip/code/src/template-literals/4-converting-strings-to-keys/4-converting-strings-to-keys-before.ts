type TemplateLiteralKeys = `${"id" | "title" | "author"}`;

type ObjWithKeys = any; //{ID: string, TITLE: string, AUTHOR: string}

export {};
