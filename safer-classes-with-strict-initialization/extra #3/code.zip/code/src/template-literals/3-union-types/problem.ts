type FrameWork = "NodeJS" | "Spring" | ".Net";
type Database = "GraphQL" | "MongoDB" | "PostgreSQL";

type Backend = any;
// "NodeJS with GraphQL"    |
// "NodeJS with MongoDB"    |
// "NodeJS with PostgreSQL" |
// "Spring with GraphQL"    |
// ...

export {};
