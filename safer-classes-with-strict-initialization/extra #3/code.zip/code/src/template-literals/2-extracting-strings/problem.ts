type Tools = "Core Java and Spring Boot" | "Golang" | "Node, MongoDB and React";

type MultipleTools = any;

export {};
